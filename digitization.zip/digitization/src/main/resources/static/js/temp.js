function drawVisualization() {
	// Some raw data (not necessarily accurate)
	var data = google.visualization
			.arrayToDataTable([
					[ 'Margin Type', 'Margin (€)', 'Minutes', 'Revenue (€)',
							'Cost (€)' ],
					[ 'Negative Margin', -15, 1748, 130, 145 ],
					[ 'Positive Margin', 693, 261925, 11581, 10888 ],
					[ 'Grand Total', 678, 263673, 11711, 11033 ]

			]);
	var view = new google.visualization.DataView(data);
	view.setColumns([ 0, 1, {
		calc : "stringify",
		sourceColumn : 1,
		type : "string",
		role : "annotation"
	}, 2, {
		calc : "stringify",
		sourceColumn : 2,
		type : "string",
		role : "annotation"
	}, 3, {
		calc : "stringify",
		sourceColumn : 3,
		type : "string",
		role : "annotation"
	}, 4, {
		calc : "stringify",
		sourceColumn : 4,
		type : "string",
		role : "annotation"
	} ]);

	var options = {
		title : 'Margin Daily Report Total (06-Feb-2019)',
		vAxis : {
			title : 'Margin',
			scaleType : 'log',
			ticks : [ -50, 0, 25000, 50000, 100000, 200000, 300000 ]
		},
		seriesType : 'bars',
		bar : {
			groupWidth : "95%"
		},

		backgroundColor : {
			fill : 'white',
			fillOpacity : 10
		},
		legend : {
			position : 'top',
			maxLines : 3
		}
	/* series: {5: {type: 'line'} } */
	};

	var chart = new google.visualization.ComboChart(document
			.getElementById('chart_div'));
	chart.draw(view, options);
}

function drawChart() {

	var data = google.visualization.arrayToDataTable([
			[ 'Sell Destination', 'Revenue (€)' ],
			[ 'ROMANIA EAD TELECOM GIPX', 344.18 ],
			[ 'ALBANIA INFOTELECOM GIPX', 183.28 ],
			[ 'SOUTH AFRICA TELKOM GIPX', 1.79 ] ]);

	var view = new google.visualization.DataView(data);
	view.setColumns([ 0,1, {
		calc : "stringify",
		sourceColumn : 1,
		type : "string",
		role : "annotation"
	}]);

	var options = {
		title : 'My Daily Activities',
		legend : {
			position : 'top',
			maxLines : 3
		}
	};

	var chart = new google.visualization.AreaChart(document
			.getElementById('chart_div2'));

	chart.draw(view, options);
}



//Chart for Revenue ###########################

function drawRevenueChart() {
	console.log(">>>>>>>>>>>>>>>> drawRevenueChart ");

	var data = google.visualization.arrayToDataTable([
			[ 'Month', 'Revenue (€)' ],
			[ 'DECEMBER', 359955 ],
			[ 'JANUARY', 368705 ],
			[ 'FEBRUARY', 85023 ] ]);

	var view = new google.visualization.DataView(data);
	view.setColumns([ 0,1, {
		calc : "stringify",
		sourceColumn : 1,
		type : "string",
		role : "annotation"
	}]);

	var options = {
		title : 'Monthly Revenue',
		legend : {
			position : 'top',
			maxLines : 3
		}
	};

	var chart = new google.visualization.AreaChart(document.getElementById('revenue-sec-chart'));

	chart.draw(view, options);
}

function drawRevenueCtsumerChart() {

        var data = google.visualization.arrayToDataTable([
          ['Month', 'ALBANIA INFOTELECOM GIPX', 'ERITREA ERITEL GIPX', 'ALBANIA INFOTELECOM GIPX'],
          ['DECEMBER',  16333,      1904, 1477],
          ['JANUARY',  4718,      5116, 1025],
          ['FEBRUARY',  4718,       1904, 1477]
        ]);
        

        var options = {
          title: 'Company Performance',
          hAxis: {title: 'Year',  titleTextStyle: {color: '#333'}},
          vAxis: {minValue: 0}
        };

        var chart = new google.visualization.AreaChart(document.getElementById('revenue-sec-customer'));
        chart.draw(data, options);

}






