function mdrMessageProcess(synth, mdrMessage) {
	
	var mdr = $("#mdr").data("mdr");
	console.log("mdr >>>>>>>>>>>>"+mdr);
	if(mdr === false){
		
		console.log("mdr >>>>>>>>>>>> hiding");
		
		$('.mdr').hide();
		$('.mdr').remove();
	} else{
        google.charts.setOnLoadCallback(drawVisualization);
        var speechMdt = new SpeechSynthesisUtterance();
        speechMdt.text = mdrMessage;
        speechMdt.onstart = function (event) {
		    console.log("Speech started >>>>>>>>>>>>"+mdrMessage);
		};

		speechMdt.onend = function (event) {
			//synth.cancel();
		    console.log("Speech ended +++++++++++");
		    $('#mdtClick').trigger("click");
		};
		
		synth.speak(speechMdt);
	}
	
}

function ttdMessageProcess(synth, ttdMessage) {
	
	var ttd = $("#ttd").data("ttd");
	console.log("ttd >>>>>>>>>>>>"+ttd);
	if(ttd === false){
		$('.ttd').hide();
		$('.ttd').remove();
		console.log("ttd >>>>>>>>>>>> hiding");
	} else{
        google.charts.setOnLoadCallback(drawChart);
        var speechTtd = new SpeechSynthesisUtterance();
        speechTtd.text = ttdMessage;
        speechTtd.onstart = function (event) {
		    console.log("Speech started >>>>>>>>>>>>"+ttdMessage);
		};

		speechTtd.onend = function (event) {
			//synth.cancel();
		    console.log("Speech ended +++++++++++ ttdMessageProcess");
		    $('#ttdClick').trigger("click");
		};
		
		synth.speak(speechTtd);
        
	}
}

function monthlyRevenueMessageProcess(synth, revenueMsg, monthlyrevenueFlag) {
	
	console.log("monthlyrevenueFlag >>>>>>>>>>>>"+monthlyrevenueFlag);
	if(monthlyrevenueFlag === false){
		//$('.revenue-sec').hide();
		$('.revenue-sec').remove();
	} else{
        google.charts.setOnLoadCallback(drawRevenueChart);
        var speechRevenue = new SpeechSynthesisUtterance();
        speechRevenue.text = revenueMsg;
        speechRevenue.onstart = function (event) {
		    console.log("Speech monthlyRevenueMessageProcess >>>>>>>>>>>>"+revenueMsg);
		};

		speechRevenue.onend = function (event) {
		    console.log("Speech ended +++++++++++ monthlyRevenueMessageProcess");
		    $('#mrClick').trigger("click");
		};
		
		synth.speak(speechRevenue);
        
	}
}


function monthlyRevenueCustomerProcess(synth, revenueCutomerMessage, monthlyrevenueCustomerFlag) {
	
	console.log("monthlyrevenueCustomerFlag >>>>>>>>>>>>"+monthlyrevenueCustomerFlag);
	if(monthlyrevenueCustomerFlag === false){
		//$('.revenue-sec-customer').hide();
		$('.revenue-sec-customer').remove();
	} else{
        google.charts.setOnLoadCallback(drawRevenueCtsumerChart);
        var speechRevenueCust = new SpeechSynthesisUtterance();
        speechRevenueCust.text = revenueCutomerMessage;
        speechRevenueCust.onstart = function (event) {
		    console.log("Speech revenueCutomerMessage >>>>>>>>>>>>"+revenueCutomerMessage);
		};

		speechRevenueCust.onend = function (event) {
		    console.log("Speech ended +++++++++++");
		    $("#mdtClick").trigger("click");
		};
		
		synth.speak(speechRevenueCust);
        
	}
}
