package com.digitization.domain;


public class Reports {
	
	private boolean marginDailyReport;
	private boolean topThreeDestinations;
	private boolean monthlyRevenue;
	private boolean monthlyCustomerRevenue;
	
	public Reports() {}
	
	public Reports(boolean marginDailyReport, boolean topThreeDestinations) {
		super();
		this.marginDailyReport = marginDailyReport;
		this.topThreeDestinations = topThreeDestinations;
	}
	public boolean isMarginDailyReport() {
		return marginDailyReport;
	}
	public void setMarginDailyReport(boolean marginDailyReport) {
		this.marginDailyReport = marginDailyReport;
	}
	public boolean isTopThreeDestinations() {
		return topThreeDestinations;
	}
	public void setTopThreeDestinations(boolean topThreeDestinations) {
		this.topThreeDestinations = topThreeDestinations;
	}
	public boolean isMonthlyRevenue() {
		return monthlyRevenue;
	}
	public void setMonthlyRevenue(boolean monthlyRevenue) {
		this.monthlyRevenue = monthlyRevenue;
	}

	public boolean isMonthlyCustomerRevenue() {
		return monthlyCustomerRevenue;
	}

	public void setMonthlyCustomerRevenue(boolean monthlyCustomerRevenue) {
		this.monthlyCustomerRevenue = monthlyCustomerRevenue;
	}

	@Override
	public String toString() {
		return "Reports [marginDailyReport=" + marginDailyReport + ", topThreeDestinations=" + topThreeDestinations
				+ ", monthlyRevenue=" + monthlyRevenue + ", monthlyCustomerRevenue=" + monthlyCustomerRevenue + "]";
	}

}
