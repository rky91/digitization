package com.digitization;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DigitizationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DigitizationApplication.class, args);
	}

}

