package com.digitization.service;

import org.springframework.stereotype.Service;

import com.digitization.domain.Reports;

@Service
public class ProfileConfigureService {
	
	private Reports reports =null;
	
	public Reports getConfiguredProfile() {
		return reports;
	}
	
	public Reports saveProfileConfigure(Reports report) {
		reports = new Reports();
		reports = report;
		return reports;
	}
	
	public void nullProfile() {
		reports = null;
	}
	
	
	

}
