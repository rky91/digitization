package com.digitization.service;

import org.springframework.stereotype.Service;

@Service
public class ReportMessageService {
	
	public String getMessageForMdt() {
		return "Briefing Margin daily Report for the 20th February.  " + 
				"Negative margin:  -15€ margin, 1748 minutes, revenue is 130€ and cost is 145€.  " + 
				"Positive margin: 693€, 261925 Minutes, Revenue is 11581€ and cost is 10888€. " + 
				"Grand Total:  Todal margin is 678€, todal minutes is 263673, todatl revenue is 11711€ and total cost is 11033€. ";
	}
	
	public String getMessageForTtd() {
		return "Briefing the Top three destinations Report for the 20th of February.  " + 
				"Carrier name: ROMANIA EAD TELECOM GIPX and revenue is 344.18€.  " + 
				"Carrier name: ALBANIA INFOTELECOM GIPX and revenue is 183.28€.  " + 
				"Carrier name: SOUTH AFRICA TELKOM GIPX and revenue is 1.79€.";
	}
	
	
	public String getMessageForMonthlyRevenue() {
		return "we would now have a quick troll over the last three month revenue and the customer contributing it.";
	}
	
	public String getMessageForMonthlyCutomerRevenue() {
		return "getMessageForMonthlyCutomerRevenue";
	}

}
