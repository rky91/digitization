package com.digitization.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.digitization.domain.Reports;
import com.digitization.service.ProfileConfigureService;
import com.digitization.service.ReportMessageService;
@Controller
public class MainController {
	
	@Autowired
	private ProfileConfigureService profileConfigureService;
	@Autowired
	private ReportMessageService reportMessageService;
	
	
	
	@GetMapping("/")
	public String login(Model model) {
		return "index";
		
	}
	
	@GetMapping("/logout")
	public String logout(Model model) {
		profileConfigureService.nullProfile();
		return "redirect:/";
		
	}
	
	@GetMapping("/home")
	public String home(Model model) {
		Reports rep = profileConfigureService.getConfiguredProfile();
		if(rep != null) {
			boolean finalFlag = false;
			System.out.println("Report home() == " + rep);
			
			if(rep.isMonthlyRevenue()) {
				finalFlag = true;
				model.addAttribute("revenueFlag", rep.isMonthlyRevenue());
				model.addAttribute("monthlyRevenueMsg", reportMessageService.getMessageForMonthlyRevenue());
				
			} else {
				model.addAttribute("revenueFlag", rep.isMonthlyRevenue());
			}
			
			if(rep.isMonthlyCustomerRevenue()) {
				finalFlag = true;
				model.addAttribute("revenueCustomerFlag", rep.isMonthlyCustomerRevenue());
				model.addAttribute("monthlyRevenueCustomerMsg", reportMessageService.getMessageForMonthlyCutomerRevenue());
				
			} else {
				model.addAttribute("revenueCustomerFlag", rep.isMonthlyCustomerRevenue());
			}
			
			if(rep.isMarginDailyReport()) {
				finalFlag = true;
				model.addAttribute("mdr", rep.isMarginDailyReport());
				model.addAttribute("mdrMsg", reportMessageService.getMessageForMdt());
			} else {
				model.addAttribute("mdr", rep.isMarginDailyReport());
			}
			
			if(rep.isTopThreeDestinations()) {
				finalFlag = true;
				model.addAttribute("ttd", rep.isTopThreeDestinations());
				model.addAttribute("ttdMsg", reportMessageService.getMessageForTtd());
			} else {
				model.addAttribute("ttd", rep.isTopThreeDestinations());
			}
			
			if(finalFlag) {
				model.addAttribute("repFlag", true);
			} else {
				model.addAttribute("repFlag", false);
			}
			
		} else {
			model.addAttribute("repFlag", false);
			model.addAttribute("ttd", false);
			model.addAttribute("revenueFlag", false);
			model.addAttribute("mdr", false);
			model.addAttribute("revenueCustomerFlag",false);
		}
		
		return "home";
	}
	
	@GetMapping("/profile")
	public String homeProfile(Model model) {
		System.out.println("Inside homeProfile().");
		Reports rep = profileConfigureService.getConfiguredProfile();
		if(rep != null) {
			model.addAttribute("report", rep); //Comment added.
		} else {
			model.addAttribute("report", new Reports()); //Comment added.
		}
		return "profile";
		
	}
	
	@GetMapping("/report/configure")
	public String homeProfileConfigure(@ModelAttribute("report") Reports report, Model model) {
		System.out.println("Inside homeProfileConfigure() --"+report);
		
		Reports rep = profileConfigureService.saveProfileConfigure(report);
		System.out.println("after save the configure -"+report);
		
		
		return "redirect:/home";
	}
	
	
	@GetMapping("/reports")
	public String homeReport(Model model) {
		
		Reports rep = profileConfigureService.getConfiguredProfile();
		if(rep != null) {
			System.out.println("homeReport retieve ------------------------------------" + rep);
			model.addAttribute("mdr", rep.isMarginDailyReport());
			model.addAttribute("ttd", rep.isTopThreeDestinations());
			model.addAttribute("revenueFlag", rep.isMonthlyRevenue());
			model.addAttribute("repFlag", true);
			
		} else {
			System.out.println("homeReport retieve ------------------------------------null");
			model.addAttribute("mdr", false);
			model.addAttribute("ttd", false);
			model.addAttribute("repFlag", false);
			model.addAttribute("revenueFlag", false);
		}
		return "reports";
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
